;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261008.430"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "fbe31b0dfb7d8eb2dffbfe4d7c52459917fd519a"
  :revdesc "fbe31b0dfb7d"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
