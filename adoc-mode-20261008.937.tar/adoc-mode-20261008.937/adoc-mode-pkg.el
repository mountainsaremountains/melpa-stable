;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20261008.937"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "674b4255f7eaf712e222d6e8a24f1ae697149ea9"
  :revdesc "674b4255f7ea"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
